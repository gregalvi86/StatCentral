import React from 'react'
import s from './Test.scss'

const Test = () => (
  <div className={s.container}>
    <h1 className={s.text}>{'test'}</h1>
  </div>
)

export default Test
