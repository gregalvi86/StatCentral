import React from 'react'
import s from './NotFound.scss'

const NotFound = () => <article className={s.container} />

export default NotFound
