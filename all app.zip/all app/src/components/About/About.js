import React from 'react'
import s from './About.scss'

const About = () => (
  <section className={s.container}>
    <h1 className={s.heading}>{'uxscoreboard'}</h1>
  </section>
)

export default About
