export const stadiums = {
  nba: {
    'Amway Center': [-81.383611, 28.539167],
    'BMO Harris Bradley Center': [-87.916944444444, 43.043611111111],
    'Bankers Life Fieldhouse': [-86.155555555556, 39.763888888889],
    'ORACLE Arena': [-122.20305555556, 37.750277777778],
    'Spectrum Center': [-80.839166666667, 35.225],
    'Staples Center': [-118.26706, 34.043102],
    'TD Garden': [-71.062227777778, 42.366302777778],
    'Toyota Center': [-95.362222222222, 29.750833333333],
    'United Center': [-87.674166666667, 41.880555555556],
    'Verizon Center': [-77.020833333333, 38.898055555556]
  }
}
