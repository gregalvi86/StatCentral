export const capitalizeStr = (string: String): String =>
  string[0].toUpperCase() + string.slice(1)
